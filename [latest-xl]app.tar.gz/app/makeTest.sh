#!/bin/sh

PWD=`pwd`

if [ $# -lt 1 ];then
echo "Please input Revision String"
exit
fi


EOC_RELEASE="\
dongyan_clt501 \
dongyan_clt201p"

EOC_RELEASE_EN="\
hexicom \
hexicom_clt501 \
hexicom_clt601 \
hexicom_clt602"


#PLC_RELEASE="\
#hexicom \
#3geasy_plc"



for model in $EOC_RELEASE
do
make MIB_NSCRTV=y REV=$1 VENDOR=$model release
done

#for model in $EOC_RELEASE_EN
#do
#make WEB=en REV=$1 VENDOR=$model release 
#done

#for model in $PLC_RELEASE
#do
#make WEB=plc REV=$1 VENDOR=$model release
#done

exit
