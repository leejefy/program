/*
 * NVRAM variable manipulation (common)
 *
 * Copyright 2004, Broadcom Corporation
 * Copyright 2009-2010, OpenWrt.org
 * All Rights Reserved.
 *
 * THIS SOFTWARE IS OFFERED "AS IS", AND BROADCOM GRANTS NO WARRANTIES OF ANY
 * KIND, EXPRESS OR IMPLIED, BY STATUTE, COMMUNICATION OR OTHERWISE. BROADCOM
 * SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A SPECIFIC PURPOSE OR NONINFRINGEMENT CONCERNING THIS SOFTWARE.
 *
 */

#include "nvram.h"

#if 0
#define TRACE(msg) \
	printf("%s(%i) in %s(): %s\n", \
		__FILE__, __LINE__, __FUNCTION__, msg ? msg : "?")

#define DBG(fmt, ...) do { fprintf(stderr, "[%s,%s,%d]: " fmt, __FILE__, __FUNCTION__, __LINE__ , ##__VA_ARGS__); fprintf(stderr, "\n"); } while(0)
#else
#define TRACE(msg)
#define DBG(fmt, ...)
#endif

static int nvram_erase_size = 0;
static int nvram_has_backup = 0;

#if defined(BOARD_EPN104)
 #define HAS_SAVEFLAG  1
#endif 

#if defined(BOARD_EPN104)

#define SYS_SAVEFLAG "/proc/manufactory/restoreflag"


static int get_saveflag(void)
{
	int fp;
	char saveflag[4];
	
	if((fp = open(SYS_SAVEFLAG, O_RDONLY)) < 0)
	{
		fprintf(stderr, "File [%s] open failed!", SYS_SAVEFLAG);
		return -1;
	}
    if(2 != read(fp, saveflag, 2))
    {
    	fprintf(stderr, "File [%s] read failed!", SYS_SAVEFLAG);
		return -1;
    }
    if(0 != close(fp))
    {
    	fprintf(stderr, "File [%s] close failed!", SYS_SAVEFLAG);
		return -1;
    }

    if('1' == saveflag[0])
    {
    	return 1;
    }
    else
    {
    	return 0;
    }
}

static int set_saveflag(int flag)
{  
//    fprintf(stderr, "set flag = %d\n", flag);
    if (flag){
        system("echo 1 > "SYS_SAVEFLAG);        
    }else {
        system("echo 0 > "SYS_SAVEFLAG);
    }
    return flag;
}

#endif 


static const char *__mtd(int cmd)
{
    switch(cmd){
        case PRIMARY_PARTITION:
            return NVRAM_PRIMARY;
        case SECONDARY_PARTITION:
            return NVRAM_SECONDARY;
        case CURRENT_PARTITION:
            #ifdef HAS_SAVEFLAG
            if (nvram_has_backup) {
                return (get_saveflag() == 1) ? NVRAM_SECONDARY : NVRAM_PRIMARY;                
            } else {
                return NVRAM_PRIMARY;
            }  
            #else
            return NVRAM_PRIMARY;
            #endif 
        case ANOTHER_PARTITION:
            #ifdef HAS_SAVEFLAG
            if (nvram_has_backup) {
                return (get_saveflag() == 1) ? NVRAM_PRIMARY : NVRAM_SECONDARY;                
            } else {
                return NVRAM_SECONDARY;
            }              
            #else
            return NVRAM_SECONDARY;
            #endif 
    }
    return NVRAM_PRIMARY;
}




/*
 * -- Helper functions --
 */

/* String hash */
static uint32_t hash(const char *s)
{
	uint32_t hash = 0;

	while (*s)
		hash = 31 * hash + *s++;

	return hash;
}

/* Free all tuples. */
static void _nvram_free(nvram_handle_t *h)
{
	uint32_t i;
	nvram_tuple_t *t, *next;

	/* Free hash table */
	for (i = 0; i < NVRAM_ARRAYSIZE(h->nvram_hash); i++) {
		for (t = h->nvram_hash[i]; t; t = next) {
			next = t->next;
            // Fatal bug: memory leak -- by einsn 2013-03-22
            if (t->value)free(t->value);
			free(t);
		}
		h->nvram_hash[i] = NULL;
	}

	/* Free dead table */
	for (t = h->nvram_dead; t; t = next) {
		next = t->next;
        // Fatal bug: memory leak -- by einsn 2013-03-22
        if (t->value)free(t->value);        
		free(t);
	}

	h->nvram_dead = NULL;
}

/* (Re)allocate NVRAM tuples. */
static nvram_tuple_t * _nvram_realloc( nvram_handle_t *h, nvram_tuple_t *t,
	const char *name, const char *value )
{
	if ((strlen(value) + 1) > NVRAM_SPACE)
		return NULL;

	if (!t) {
		if (!(t = malloc(sizeof(nvram_tuple_t) + strlen(name) + 1)))
			return NULL;

		/* Copy name */
		t->name = (char *) &t[1];
		strcpy(t->name, name);

		t->value = NULL;
	}

	/* Copy value */
	if (!t->value || strcmp(t->value, value))
	{
		if(!(t->value = (char *) realloc(t->value, strlen(value)+1)))
			return NULL;
		strcpy(t->value, value);
		t->value[strlen(value)] = '\0';
	}
	

	return t;
}

/* (Re)initialize the hash table. */
static int _nvram_rehash(nvram_handle_t *h)
{
	nvram_header_t *header = nvram_header(h);
	char /*buf[] = "0xXXXXXXXX",*/ *name, *value, *eq;

	/* (Re)initialize hash table */
	_nvram_free(h);

	/* Parse and set "name=value\0 ... \0\0" */
	name = (char *) &header[1];

	for (; *name; name = value + strlen(value) + 1) {
		if (!(eq = strchr(name, '=')))
			break; 
		*eq = '\0';
		value = eq + 1;
		nvram_set(h, name, value);
		*eq = '=';
	}

	h->has_change = 0;
	return 0;
}


/*
 * -- Public functions --
 */

/* Get nvram header. */
nvram_header_t * nvram_header(nvram_handle_t *h)
{
	return (nvram_header_t *) &h->mmap[h->offset];
}

/* Get the value of an NVRAM variable. */
char * nvram_get(nvram_handle_t *h, const char *name)
{
	uint32_t i;
	nvram_tuple_t *t;
	char *value;

	if (!name)
		return NULL;

	/* Hash the name */
	i = hash(name) % NVRAM_ARRAYSIZE(h->nvram_hash);

	/* Find the associated tuple in the hash table */
	for (t = h->nvram_hash[i]; t && strcmp(t->name, name); t = t->next);

	value = t ? t->value : NULL;

	return value;
}

/* Set the value of an NVRAM variable. */
int nvram_set(nvram_handle_t *h, const char *name, const char *value)
{
	uint32_t i;
	nvram_tuple_t *t, *u, **prev;

	/* Hash the name */
	i = hash(name) % NVRAM_ARRAYSIZE(h->nvram_hash);

	/* Find the associated tuple in the hash table */
	for (prev = &h->nvram_hash[i], t = *prev;
		 t && strcmp(t->name, name); prev = &t->next, t = *prev);

	/* (Re)allocate tuple */
	if (!(u = _nvram_realloc(h, t, name, value)))
		return -12; /* -ENOMEM */

	h->has_change = 1;
	
	/* Value reallocated */
	if (t && t == u){
		return 0;
	}

	/* Move old tuple to the dead table */
	if (t) {
		*prev = t->next;
		t->next = h->nvram_dead;
		h->nvram_dead = t;
	}

	/* Add new tuple to the hash table */
	u->next = h->nvram_hash[i];
	h->nvram_hash[i] = u;
	
	return 0;
}

/* Unset the value of an NVRAM variable. */
int nvram_unset(nvram_handle_t *h, const char *name)
{
	uint32_t i;
	nvram_tuple_t *t, **prev;

	if (!name)
		return 0;

	/* Hash the name */
	i = hash(name) % NVRAM_ARRAYSIZE(h->nvram_hash);

	/* Find the associated tuple in the hash table */
	for (prev = &h->nvram_hash[i], t = *prev;
		 t && strcmp(t->name, name); prev = &t->next, t = *prev);

	/* Move it to the dead table */
	if (t) {
		*prev = t->next;
		t->next = h->nvram_dead;
		h->nvram_dead = t;
		h->has_change = 1;		
	}
	return 0;
}

void nvram_unset_all(nvram_handle_t *h)
{
	_nvram_free(h);
}


/* Get all NVRAM variables. */
nvram_tuple_t * nvram_getall(nvram_handle_t *h)
{
	int i;
	nvram_tuple_t *t, *l, *x;

	l = NULL;

	for (i = 0; i < NVRAM_ARRAYSIZE(h->nvram_hash); i++) {
		for (t = h->nvram_hash[i]; t; t = t->next) {
			if( (x = (nvram_tuple_t *) malloc(sizeof(nvram_tuple_t))) != NULL )
			{
				x->name  = t->name;
				x->value = t->value;
				x->next  = l;
				l = x;
			}
			else
			{
				break;
			}
		}
	}

	return l;
}

/* Regenerate NVRAM. */
int nvram_commit(nvram_handle_t *h)
{
	nvram_header_t *header = nvram_header(h);
//	char *init, *config, *refresh, *ncdl;
	char *ptr, *end;
	int i;
	nvram_tuple_t *t;
	nvram_header_t tmp;
	uint8_t crc;

	/* Regenerate header */
	header->magic = NVRAM_MAGIC;
	header->crc_ver_init = (NVRAM_VERSION << 8);
	
	/* Clear data area */
	ptr = (char *) header + sizeof(nvram_header_t);
	memset(ptr, 0xFF, NVRAM_SPACE - sizeof(nvram_header_t));
	memset(&tmp, 0, sizeof(nvram_header_t));

	/* Leave space for a double NUL at the end */
	end = (char *) header + NVRAM_SPACE - 2;

	/* Write out all tuples */
	for (i = 0; i < NVRAM_ARRAYSIZE(h->nvram_hash); i++) {
		for (t = h->nvram_hash[i]; t; t = t->next) {
			if ((ptr + strlen(t->name) + 1 + strlen(t->value) + 1) > end)
				break;
			ptr += sprintf(ptr, "%s=%s", t->name, t->value) + 1;
		}
	}

	/* End with a double NULL and pad to 4 bytes */
	*ptr = '\0';
	ptr++;

	if( (int)ptr % 4 )
		memset(ptr, 0, 4 - ((int)ptr % 4));

	ptr++;

	/* Set new length */
	header->len = NVRAM_ROUNDUP(ptr - (char *) header, 4);

	/* Little-endian CRC8 over the last 11 bytes of the header */
	tmp.crc_ver_init   = header->crc_ver_init;
	tmp.config_refresh = header->config_refresh;
	tmp.config_ncdl    = header->config_ncdl;
	crc = hndcrc8((unsigned char *) &tmp + NVRAM_CRC_START_POSITION,
		sizeof(nvram_header_t) - NVRAM_CRC_START_POSITION, 0xff);

	/* Continue CRC8 over data bytes */
	crc = hndcrc8((unsigned char *) &header[0] + sizeof(nvram_header_t),
		header->len - sizeof(nvram_header_t), crc);

	/* Set new CRC8 */
	header->crc_ver_init |= crc;

	/* Write out */
	msync(h->mmap, h->length, MS_SYNC);
	fsync(h->fd);

	/* Reinitialize hash table */
	return _nvram_rehash(h);
	/* return 0; */
}

/* Open NVRAM and obtain a handle. */
nvram_handle_t * nvram_open(const char *file, int rdonly)
{
	int i;
	int fd;
	char *mtd = NULL;
	nvram_handle_t *h;
//	nvram_header_t *header;
	int offset = -1;
	int endian_unmatch = 0;
	uint32_t v32;

    TRACE("-->nvram_open");
    DBG("get erase size:%d, file=%s, readonly:%d", nvram_erase_size, file ? file : "null", rdonly);
    
	/* If erase size or file are undefined then try to define them */
	if( (nvram_erase_size == 0) || (file == NULL) )
	{
		/* Finding the mtd will set the appropriate erase size */
		if( (mtd = nvram_find_mtd(__mtd(CURRENT_PARTITION), &nvram_erase_size, NULL)) == NULL || nvram_erase_size == 0 )
		{
			fprintf(stderr, "nvram find mtd = null\n");
			free(mtd);
			return NULL;
		}
	}    

	if( (fd = open(file ? file : mtd, O_RDWR)) > -1 )
	{
		char *mmap_area = (char *) mmap(
			NULL, nvram_erase_size, PROT_READ | PROT_WRITE,
			(( rdonly == NVRAM_RO ) ? MAP_PRIVATE : MAP_SHARED) | MAP_LOCKED, fd, 0);

		if( mmap_area != MAP_FAILED )
		{
			for( i = 0; i <= ((nvram_erase_size - NVRAM_SPACE) / sizeof(uint32_t)); i++ )
			{
				/*
				if (i < 5){
					fprintf(stderr, "%08x:%08x\n", ((uint32_t *)mmap_area)[i], NVRAM_MAGIC);
				}else {
					break;
				}*/
				v32 = ((uint32_t *)mmap_area)[i];
				
				if( v32 == NVRAM_MAGIC )
				{
					endian_unmatch = 0;
					offset = i * sizeof(uint32_t);
					break;
				} else if( nvram_swap32(v32) == NVRAM_MAGIC )
				{
					endian_unmatch = 1;
					offset = i * sizeof(uint32_t);
					break;
				}
				
			}

			if( offset < 0 )
			{
            	fprintf(stderr, "nvram magic lost, could not find valid nvram partition\n");			    
                if (rdonly){
                    munmap(mmap_area, nvram_erase_size); 
                    close(fd);
                    if (mtd) free(mtd);
                    return NULL;
                }
			}
            
			if( (h = malloc(sizeof(nvram_handle_t))) != NULL )
			{
				memset(h, 0, sizeof(nvram_handle_t));

				h->fd     = fd;
				h->mmap   = mmap_area;
				h->length = nvram_erase_size;
				h->offset = offset < 0 ? 0 : offset;
				h->endian_unmatch = endian_unmatch;
                h->has_backup = nvram_has_backup;

                // not found valid one, reset to empty
                if (offset < 0){
                    nvram_commit(h);
                }else {   
                    _nvram_rehash(h);
                }
                free(mtd);
                
                return h;
                
/*
				if( (header->magic == NVRAM_MAGIC) || (nvram_swap32(header->magic) == NVRAM_MAGIC) )
				{
					_nvram_rehash(h);
					free(mtd);
					return h;
				}
				else
				{
					munmap(h->mmap, h->length);
					free(h);
					return NULL;					
				}
*/
			}else {
                fprintf(stderr, "nvram malloc failed\n");
                munmap(mmap_area, nvram_erase_size); 
            }
            
		}else {
			fprintf(stderr, "nvram mmap failed\n");
            close(fd);
		}
	}else {
		fprintf(stderr, "nvram open %s failed\n", file);
	}

	free(mtd);
	return NULL;
}

/* Close NVRAM and free memory. */
int nvram_close(nvram_handle_t *h)
{
	_nvram_free(h);
	munmap(h->mmap, h->length);
	close(h->fd);
	free(h);

	return 0;
}


char *nvram_find_mtd(const char *mtd_name, int *mtd_size, int *mtd_block_size)
{
        FILE *fp;
        int i, size = 0, esize = 0, tail;
        char dev[256], buf[256];
    	struct stat s;  
    	char *path = NULL;        

        TRACE("-->nvram_find_mtd");
    
        fp = fopen("/proc/mtd", "r");
        if (fp == NULL){
                printf("Can not open /proc/mtd\n");
                return NULL;
        }

        sprintf(buf, "mtd%%d: %%08x %%08x \"%s\" %%d", mtd_name);

        while(fgets(dev, sizeof(dev), fp)){
                // trim \n\r
                i = 0;
                while(dev[i]){
                        if ((dev[i] == '\n') || (dev[i] == '\r')){
                                dev[i] = '\0';
                        }
                        i ++;
                }

                tail = 0;
                strcat(dev, " 1234");
                if ((sscanf(dev, buf, &i, &size, &esize, &tail) == 4) && (size > 0) && (tail == 1234)){
        				sprintf(dev, "/dev/mtdblock/%d", i);
        				if( stat(dev, &s) > -1 && (s.st_mode & S_IFBLK) )
        				{
        					if( (path = (char *) malloc(strlen(dev) + 1)) != NULL )
        					{
        						strncpy(path, dev, strlen(dev)+1);
        						break;
        					}
        				}
        				else
        				{
        					sprintf(dev, "/dev/mtdblock%d", i);
        					if( stat(dev, &s) > -1 && (s.st_mode & S_IFBLK) )
        					{
        						if( (path = (char *) malloc(strlen(dev) + 1)) != NULL )
        						{
        							strncpy(path, dev, strlen(dev)+1);
        							break;
        						}
        					}
        				}  
                        break;
                }
        }

        if (mtd_size){
            *mtd_size = size;
        }

        if (mtd_block_size){
            *mtd_block_size = esize;
        }
        DBG("find nvram partition on %s, size:%d, block-size:%d", path, size, esize);
        fclose(fp);        
        return path;
}


/* Check NVRAM staging file. */
char * nvram_find_staging(void)
{
	struct stat s;
    TRACE("--->nvram_find_staging");

	if( (stat(NVRAM_STAGING, &s) > -1) && (s.st_mode & S_IFREG) )
	{
		return NVRAM_STAGING;
	}

	return NULL;
}

/* Copy NVRAM contents to staging file. */
int nvram_to_staging(void)
{
	int fdmtd, fdstg, stat;
	char *mtd = NULL;
	char *buf = NULL;
    int buf_size;

    TRACE("-->nvram_to_staging");

    mtd = nvram_find_mtd(__mtd(CURRENT_PARTITION), &nvram_erase_size, NULL);

    fprintf(stderr, "\nnvram: loading %s(size=%d) to staging ..", mtd ? mtd : "(null)", nvram_erase_size);
        
	stat = -1;

	if( (mtd != NULL) && (nvram_erase_size > 0) )
	{    
        DBG("get erase size:%d", nvram_erase_size);	
	    buf_size = nvram_erase_size;
        
        buf = (char *)malloc(buf_size);
        if (buf == NULL){
            fprintf(stderr, "\nmalloc(%d) failed", buf_size);
            return stat;
        }

        if( (fdmtd = open(mtd, O_RDONLY)) > -1 )
		{
			if( read(fdmtd, buf, buf_size) == buf_size )
			{
				if((fdstg = open(NVRAM_STAGING, O_WRONLY | O_CREAT, 0600)) > -1)
				{
					write(fdstg, buf, buf_size);
					fsync(fdstg);
					close(fdstg);
                    fprintf(stderr, "done\n");
					stat = 0;
				}else {
					fprintf(stderr, "\nnvram: open '%s' failed", NVRAM_STAGING);
				}
			}else {
				fprintf(stderr, "\nnvram: read '%s' failed", mtd);
			}

			close(fdmtd);
		}else {
			fprintf(stderr, "\nnvram: open '%s' failed", mtd);
		}
	}else {
		fprintf(stderr, "\nnvram: mtd = null or nvram size = 0");
	}

	if (mtd) free(mtd);
    if (buf) free(buf);
    
	return stat;
}

/* Copy staging file to NVRAM device. */
int staging_to_nvram(void)
{
	int fdmtd, fdstg, stat;
	char *mtd = NULL;
	char *buf = NULL;
    int buf_size;
    
#ifdef HAS_SAVEFLAG
    /* always saving to another partition */
    mtd = nvram_find_mtd(__mtd(ANOTHER_PARTITION), &nvram_erase_size, NULL);
#else
    mtd = nvram_find_mtd(__mtd(CURRENT_PARTITION), &nvram_erase_size, NULL);
#endif 

    fprintf(stderr, "\nnvram: saving staging to %s(size=%d)", mtd ? mtd : "(null)", nvram_erase_size);

	stat = -1;

	if( (mtd != NULL) && (nvram_erase_size > 0) )
	{
	    buf_size = nvram_erase_size;
        DBG("get erase size:%d", nvram_erase_size);	
        
        buf = (char *)malloc(buf_size);
        if (buf == NULL){
            fprintf(stderr, "\nmalloc(%d) failed", buf_size);
            return stat;
        }
        
		if( (fdstg = open(NVRAM_STAGING, O_RDONLY)) > -1 )
		{
			if( read(fdstg, buf, buf_size) == buf_size )
			{
				if( (fdmtd = open(mtd, O_WRONLY | O_SYNC)) > -1 )
				{
					write(fdmtd, buf, buf_size);
					fsync(fdmtd);
					close(fdmtd);
					stat = 0;
                    #ifdef HAS_SAVEFLAG   
                    if (nvram_has_backup){
                        set_saveflag((get_saveflag() == 1) ? 0 : 1);
                    }
                    #endif 
                     fprintf(stderr, "done\n");
				}else {
                    fprintf(stderr, "\nnvram: open '%s' failed", mtd);    
                }
                #ifndef HAS_SAVEFLAG
                if (nvram_has_backup){
                    free(mtd);
                    mtd = NULL;
                    mtd =  nvram_find_mtd(__mtd(ANOTHER_PARTITION), &nvram_erase_size, NULL);
                    
                    fprintf(stderr, "\nnvram: saving staging to %s(size=%d)", mtd ? mtd : "(null)", nvram_erase_size);   
    				if( (fdmtd = open(mtd, O_WRONLY | O_SYNC)) > -1 )
    				{
    					write(fdmtd, buf, buf_size);
    					fsync(fdmtd);
    					close(fdmtd);
                        fprintf(stderr, "done\n");
    				} else {
                        fprintf(stderr, "\nnvram: open '%s' failed", mtd);
                    }                   
                }
                #endif /* not HAS_SAVEFLAG */
			}else {
                fprintf(stderr, "\nnvram: read '%s' failed", NVRAM_STAGING);
            }

			close(fdstg);

			//if( !stat )
			//	stat = unlink(NVRAM_STAGING) ? 1 : 0;
		}else {
            fprintf(stderr, "\nnvram: open '%s' failed", NVRAM_STAGING);
        }
	}else {
        fprintf(stderr, "\nnvram: unknown mtd(%s) or size(%d)",  mtd ? mtd : "(null)", nvram_erase_size);
    }

    if (mtd) free(mtd);
    if (buf) free(buf);
    
	return stat;
}

nvram_handle_t * nvram_open_rdonly(void)
{
	const char *file;

    TRACE("-->nvram_open_rdonly");
        
    file = nvram_find_staging();

	if( file == NULL )
		file = nvram_find_mtd(__mtd(CURRENT_PARTITION), &nvram_erase_size, NULL);

	if( file != NULL )
		return nvram_open(file, NVRAM_RO);

	return NULL;
}

nvram_handle_t * nvram_open_staging(void)
{
    TRACE("-->nvram_open_staging");
	if( nvram_find_staging() != NULL || nvram_to_staging() == 0 )
		return nvram_open(NVRAM_STAGING, NVRAM_RW);

	return NULL;
}


static int nvram_init_recover(char *dev_from, int from_size, char *dev_to, int to_size)
{
    int fd_from, fd_to, result = 0;
    char *buf = NULL;
    

    if ((from_size <= 0) || (to_size <= 0)){
        fprintf(stderr, "nvram recover(%s->%s) : nvram partitions size error [%d,%d]\n", dev_from, dev_to, from_size, to_size);        
        return result;
    }

    fd_from = open(dev_from, O_RDONLY);
    if (fd_from < 0){
        fprintf(stderr, "nvram recover(%s->%s) : open %s return %d\n", dev_from, dev_to, dev_from, fd_from);
        return result;
    }

    if (from_size < to_size){
        to_size = from_size;
    }
    
    buf = (char *)malloc(to_size);
    if (buf == NULL){
        fprintf(stderr, "nvram recover(%s->%s) : malloc(%d) failed\n", dev_from, dev_to, to_size);
        close(fd_from);
        return result;
    }
    
    if( read(fd_from, buf, to_size) == to_size )
    {
        if( (fd_to = open(dev_to, O_WRONLY | O_SYNC)) > -1 )
        {
        	write(fd_to, buf, to_size);
        	fsync(fd_to);
        	close(fd_to);
        } else {
            fprintf(stderr, "nvram recover(%s->%s) : open %s return %d\n", dev_from, dev_to, dev_to, fd_to);
        }            
    }else {
        fprintf(stderr, "nvram recover(%s->%s) : read %s failed\n", dev_from, dev_to, dev_from);
        result = 0;
    }
    
    close(fd_from);

    if (buf) free(buf);
    
    return result;
}



static int nvram_init_check(char *nvram_dev, int size, uint8_t *crc_return)
{
    int fd, result = 0;
    char *buf = NULL;
    nvram_header_t *hdr;
    uint8_t crc;

    if (size <= 0){
        fprintf(stderr, "nvram check(%s) : nvram partition size error [%d]\n", nvram_dev, size);        
        return result;
    }

    fd = open(nvram_dev, O_RDONLY);
    if (fd < 0){
        fprintf(stderr, "nvram check(%s) : open return %d\n", nvram_dev, fd);
        return result;
    }

    buf = (char *)malloc(size);
    if (buf == NULL){
        fprintf(stderr, "nvram check(%s) : malloc(%d) failed\n", nvram_dev, size);
        close(fd);
        return result;
    }
    
    if(read(fd, buf, size) == size )
    {
        result = 1;
        hdr = (nvram_header_t *)buf;
        if ((hdr->magic != NVRAM_MAGIC) && (nvram_swap32(hdr->magic) != NVRAM_MAGIC)){
            result = 0;
            fprintf(stderr, "nvram check(%s) : unknown magic code [%08x]\n", nvram_dev, hdr->magic);            
        }else {
            if (nvram_swap32(hdr->magic) == NVRAM_MAGIC){
                hdr->len = nvram_swap32(hdr->len);
                hdr->crc_ver_init = nvram_swap32(hdr->crc_ver_init);
            }
        }
        
        if (result && ((hdr->len <= sizeof(nvram_header_t))
            || (hdr->len > NVRAM_SPACE))){
            result = 0;
            fprintf(stderr, "nvram check(%s) : invalid length in header [%d]\n", nvram_dev, hdr->len);  
        }

        if (result){
            crc = hndcrc8((unsigned char *) &hdr[0] + NVRAM_CRC_START_POSITION,
                hdr->len - NVRAM_CRC_START_POSITION, 0xff);   
            if (crc != (hdr->crc_ver_init & 0xff)){
                result = 0;
                fprintf(stderr, "nvram check(%s) : CRC unmatch [%02x(computed), %02x(stored)]\n", nvram_dev, crc, hdr->crc_ver_init & 0xff);  
            }else {
                if (crc_return){
                    *crc_return = crc;
                }
            }
        }
       
    }else {
        fprintf(stderr, "nvram check(%s) : read failed\n", nvram_dev);
        result = 0;
    }
    
    close(fd);

    if (buf) free(buf);
    
    return result;
}


int nvram_init(void)
{
    char *primary = NULL, *secondary = NULL;
    int p_size, p_esize, s_size, s_esize;
    int p_check, s_check, ret = 0;
    uint8_t p_crc, s_crc;
    
    primary = nvram_find_mtd(__mtd(PRIMARY_PARTITION), &p_size, &p_esize);
    secondary = nvram_find_mtd(__mtd(SECONDARY_PARTITION), &s_size, &s_esize);

    if (primary == NULL){
        fprintf(stderr, "Can not find NVRAM primary partition : %s\n", __mtd(PRIMARY_PARTITION));
        goto err_exit;
    }

    if (secondary == NULL){
        fprintf(stderr, "Can not find NVRAM secondary partition : %s\n", __mtd(SECONDARY_PARTITION));
    }
    

    if (primary && secondary){
        if ((p_size != s_size) || (p_esize != s_esize)){
            fprintf(stderr, "Two partitions of NVRAM have different sizes(%08x, %08x : %08x %08x)\n", p_size, p_esize, s_size, s_esize);
            goto err_exit;
        }

        nvram_has_backup = 1;

        p_check = nvram_init_check(primary, p_size, &p_crc);
        s_check = nvram_init_check(secondary, s_size, &s_crc);
        if (p_check && !s_check){
            fprintf(stderr, "NVRAM secondary partition was damaged, recover it with primary!\n");
            ret = nvram_init_recover(primary, p_size, secondary, s_size);
        }else if (!p_check && s_check){
            fprintf(stderr, "NVRAM primary partition was damaged, recover it with secondary!\n");
            ret = nvram_init_recover(secondary, s_size, primary, p_size);            
        }else if (!p_check && !s_check){
            fprintf(stderr, "NVRAM primary and secondary partitions were damaged, recovery do nothing!\n");            
        }else {
        /* if has saveflag, crcs in two parts may not match */
            #ifndef HAS_SAVEFLAG
            if (p_crc != s_crc)
            {
                fprintf(stderr, "Two partitions of NVRAM have different CRCs (%02x : %02x), sync to secondary!\n", p_crc, s_crc);                 
                ret = nvram_init_recover(primary, p_size, secondary, s_size);                
            }
            #endif 
            ret = 1;
        }
    }

    
    err_exit:

    if (primary){
       free(primary);
    }
       
    if (secondary){
       free(secondary);
    }

    return ret;
}    


