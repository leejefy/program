#!/bin/sh

export MIBS=ALL

SCALAR_CONF=mib2c.scalar_hexicom.conf
TABLE_CONF=mib2c.iterate_hexicom.conf
TARGET_DIR=../agent/mibgroup/nscrtv/mib2c_new


SCALAR_NODES="\
modEoCCBATDevInfoGroup \
modEoCCBATNetworkAttrGroup \
modEoCCBATDevStatusGroup \
modEoCCBATSNMPSettingGroup \
modEoCCBATOtherAdminGroup \
modEoCSoftwareUpgradeGroup \
modEoCCNUWhiteList \
modEoCOnlineCNU \
modEoCCNUService \
modEoCCNUPort \
modEoCTrapGroup"


TABLE_NODES="\
modEoCCBATRFTable \
modEoCCBATMACVlanTable \
modEoCCBATMACBroadcastTable \
modEoCCBATMACCNUIsolationTable \
modEoCOnlineCBATTable \
modEoCSoftwareUpgradeTable \
modEoCCNUWhiteListTable \
modEoCOnlineCNUTable \
modEoCCNUServiceTable \
modEoCCNUPortTable \
modEoCRealTimeStatisticTable \
modEoCIGMPSnoopingGroup"


echo "Creating Scalar Nodes..."
for i in ${SCALAR_NODES}
do 
../mib2c -c ${SCALAR_CONF} $i
done

echo "Creating Table Nodes..."
for i in ${TABLE_NODES}
do 
../mib2c -c ${TABLE_CONF} $i
done

find -name "*.c~" | xargs rm -f
find -name "*.h~" | xargs rm -f 


#mkdir -p ${TARGET_DIR}

#mv mod* ${TARGET_DIR}



exit 0




