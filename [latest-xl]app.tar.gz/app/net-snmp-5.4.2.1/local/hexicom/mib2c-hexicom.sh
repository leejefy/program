#!/bin/sh

export MIBS=ALL

SCALAR_CONF=mib2c.scalar_hexicom.conf
TABLE_CONF=mib2c.iterate_hexicom.conf
TARGET_DIR=../../agent/mibgroup/hexicom


SCALAR_NODES="\
eocCLTSystemInfo \
eocCLTConfigSystem \
eocConfigNetworking \
eocConfigService \
eocConfigAdministrator \
eocConfigRemoteUpgrade \
eocConfigRTC \
eocCLTConfigInterface \
eocCLTConfigVLAN \
eocConfigCableScalar \
eocConfigSNMPScalar \
eocCLTTemplateGroup \
eocCLTNetworkUnitGroup \
eocCLTNetworkUnitScalarGroup \
eocConfigStormRateLimitation \
eocConfigSyslogScalars \
eocCLTDebug"


TABLE_NODES="\
eocConfigAdministratorTable \
eocConfigInterfaceTable \
eocConfigInterfaceStatisticsTable \
eocConfigVLANTable \
eocConfigVLANTrunkTable \
eocConfigVLANHybridTable \
eocConfigCableTable \
eocConfigSNMPTrapTable \
eocDeviceModelTable \
eocTemplateTable \
eocTemplateInterfaceTable \
eocNetworkUnitTopologyTable \
eocNetworkUnitInterfaceTable \
eocNetworkUnitStatisticsTable \
eocNetworkUnitUserListTable \
eocConfigCableUpgradeTable \
eocConfigCableUpgradeResultTable"


TABLE_NODEST="\
eocConfigVLANTable \
eocTemplateTable \
eocNetworkUnitTopologyTable \
eocNetworkUnitInterfaceTable \
eocNetworkUnitStatisticsTable \
eocNetworkUnitUserListTable"


#echo "Creating Scalar Nodes..."
#for i in ${SCALAR_NODES}
#do 
#./mib2c -c ${SCALAR_CONF} $i
#done

echo "Creating Table Nodes..."
for i in ${TABLE_NODES}
do 
./mib2c -c ${TABLE_CONF} $i
done

find -name "*.c~" | xargs rm -f
find -name "*.h~" | xargs rm -f 

mkdir -p ${TARGET_DIR}

mv eoc* ${TARGET_DIR}

exit 0




