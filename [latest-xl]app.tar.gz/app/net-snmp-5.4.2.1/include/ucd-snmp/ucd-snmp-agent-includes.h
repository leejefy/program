#ifdef UCD_COMPATIBLE

#include <net-snmp/agent/net-snmp-agent-includes.h>

#else

#error "Please update your headers or configure using --enable-ucd-snmp-compatibility"

#endif
