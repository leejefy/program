#include <stdio.h>
#include <string.h>



int main(int argc, char **argv)
{
	FILE *fp;
	int i, match, size, esize, tail;
	char dev[256], buf[256];

	if (argc < 2){
		printf("Usage: mtd name\n");
		return 1;
	}

	fp = fopen("/proc/mtd", "r");
	if (fp == NULL){
		printf("Can not open /proc/mtd\n");
		return 1;
	}
	
	match = 0;
	sprintf(buf, "mtd%%d: %%08x %%08x \"%s\" %%d", argv[1]);

	while(fgets(dev, sizeof(dev), fp)){
		// trim \n\r
		i = 0;
		while(dev[i]){
			if ((dev[i] == '\n') || (dev[i] == '\r')){
				dev[i] = '\0';
			}
			i ++;
		}		

		tail = 0;
		strcat(dev, " 1234");
		if ((sscanf(dev, buf, &i, &size, &esize, &tail) == 4) && (tail == 1234)){
			printf("%d", i);
			match = 1;
			break;
		}
	}

	fclose(fp);
	
	return !match;
}
