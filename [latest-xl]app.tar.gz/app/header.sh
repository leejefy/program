#!/bin/sh





function add_comment()
{
 tmp=$1.tmp
 name=`basename $1`
 echo "" > $tmp
 echo "/*" >> $tmp
 echo "Copyright (c) 2011,  Shenzhen Hexicom Technologies Co., Ltd." >> $tmp
 echo "All rights reserved." >> $tmp
 echo "" >> $tmp
 echo "File         : $name"  >> $tmp
 echo "Status       : Current" >> $tmp
 echo "Description  :	" >> $tmp
 echo "" >> $tmp
 echo "Author       : Einsn Liu" >> $tmp
 echo "Contact      : liuchuansen@hexicomtech.com" >> $tmp
 echo "" >> $tmp
 echo "Revision     : 2011-09-18" >> $tmp
 echo "Description  : Primary beta released" >> $tmp
 echo "*/"  >> $tmp
 echo "" >> $tmp
 echo "" >> $tmp
 echo "" >> $tmp
 cat $1 >> $tmp 
 mv $tmp $1
 dos2unix $1
 echo -e "\n>>>Add Comment to $1 successfully\n"
}




function file_handle()
{
 read -n1 -p "Do you want to add comment to $1[y/n](default:y):" answer
 case $answer in 
 N|n)
  echo "";;
 *)
  add_comment $1;;
 esac

}


function dir_handle()
{
 read -n1 -p "Do you want to enter directory $1[y/n](default:n):" answer
 case $answer in 
 Y|y)
   echo "-->Enter directory $1"
   parse_dir $1
   echo "<--Exit directory $1"
   ;;
 *)
   ;;
 esac
}


function parse_dir()
{
 FILES=`ls $1`
 for f in $FILES
 do 
  fp=$1/$f
  if [ -d $fp ]
  then 
	 dir_handle $fp
  else 
   if [ -h $fp ]
   then 
    echo "$f is link file, neglected."
   elif [ "${f##*.}" = "c" -o "${f##*.}" = "h" ]
   then 
    file_handle $fp
   else 
    echo "$f is not a '.c' or '.h' file, neglected."
   fi
  fi 
 done
}

DIR=$(pwd)

if [ $# -lt 1 ]
then
parse_dir $DIR
else 
 if [ -d $1 ]
 then 
 		parse_dir $DIR/$1
 elif [ -f $1 ]
 then 
   add_comment $DIR/$1
 else  
   echo "$1 does not exist!"
 fi
fi

exit 0

